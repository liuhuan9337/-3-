//
//  NumberOneViewController.h
//  MyWork
//
//  Created by lanou3g on 16/3/23.
//  Copyright © 2016年 Sea. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NumberOneViewController : UIViewController
@property(nonatomic,strong)NSString *pssuae;


@end
