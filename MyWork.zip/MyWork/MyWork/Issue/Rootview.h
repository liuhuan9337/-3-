//
//  Rootview.h
//  MyWork
//
//  Created by 刘欢 on 16/3/24.
//  Copyright © 2016年 Sea. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Rootview : UIView 
@property(nonatomic,strong)UITextView *textfield;
@property(nonatomic,strong)UIButton *button;
@property(nonatomic,strong)UIButton *buttonFirst;
@end
