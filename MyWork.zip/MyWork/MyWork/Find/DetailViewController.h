//
//  DetailViewController.h
//  WhereAreYou
//
//  Created by lanou3g on 16/3/15.
//  Copyright © 2016年 lanou3g. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController




@end
