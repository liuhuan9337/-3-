//
//  ChatListViewController.h
//  MyWork
//
//  Created by 刘欢 on 16/3/25.
//  Copyright © 2016年 Sea. All rights reserved.
//

#import <LeanChatLib/LeanChatLib.h>

@interface ChatListViewController : CDChatListVC

@end
